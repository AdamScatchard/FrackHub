<?php
    $bypass = true;
    include ($lib_dir . "email_class.php");
    $e_mail = new emailer();
    echo "<h1>TEST PAGE FOR DEVS</h1>";
    $user_data = $db->getRow("fh_users", "id=1");
    $e_mail->send_email("registration", $user_data );
    
?>