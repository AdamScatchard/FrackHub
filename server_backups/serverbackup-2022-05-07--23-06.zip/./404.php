<center><h1>Error: 404. Page not found</h1>
<sup>insert funny image here</sup></center>