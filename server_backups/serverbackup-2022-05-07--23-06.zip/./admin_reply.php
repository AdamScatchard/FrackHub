<?php
    permission_check("admin_contactUs");
    echo "<h2>Contact Reply:</h2>";
    echo "<hr>";
?>