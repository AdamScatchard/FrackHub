<h1>
    Unauthorised Access
</h1>
<p>Please check the following...
<ul>
    <li>Cookies are unabled on this browser</li>
    <li>You have logged in</li>
    <li>Your credentials allow you access to this page normally</li>
</ul><br>
Where the problem persists, please contact technical support<br>
</p>