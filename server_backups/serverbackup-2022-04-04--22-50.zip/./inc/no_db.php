<?php
echo "<h1>Contact System Support</h1>";
echo "<p>There is an issue connecting to the database, please verify the credentials.</p>";
?>