<!DOCTYPE html>
<html>
<head>
	<title>Search Bar</title>
</head>
<body>

<form method="post">
<label>Search</label>
<input type="text" name="search">
<input type="submit" name="submit">
	
</form>

</body>
</html>

<?php
	include("page_init.php")
//$con = new PDO("mysql:host=localhost;dbname=id18498157_frackhubtestingdb",'id18498157_frackhubtdb','BM1b*2f3m!*oy0j0');
           ###("mysql:host=localhost;dbname=id18498157_frackhubtestingdb",'id18498157_frackhubtdb','BM1b*2f3m!*oy0j0');

if (isset($_POST["submit"])) {
	$str = $_POST["search"];
	$sth = $con->prepare("SELECT * FROM `fh_adverts` WHERE name LIKE '$str%'");
	

	$sth->setFetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();

	if($row = $sth->fetch())
	{
		?>
		<br><br><br>
		<table>
			<tr>
				<th>Name</th>
				<th>Description</th>
			</tr>
			<tr>
				<td><?php echo $row->Name; ?></td>
				<td><?php echo $row->Description;?></td>
			</tr>

		</table>
<?php 
	}
		
		
		else{
			echo "Name does not exist";
		}


}

?>
