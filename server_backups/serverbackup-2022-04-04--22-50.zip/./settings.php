<?php
$settings = true;
$debug = true;

// Database settings
$db_sn = "id18498157_frackhubtdb";
$db_pwd = "Bm1b*2F3m!*oy0j0";
$db_db = "id18498157_frackhubtestingdb";
$db_host = "localhost";
$encryption_key = 12;

// Library and Dependant Folders

$lib_dir = "libs/";
$css_dir = "css/";
$js_dir = "js/";
$inc_dir = "inc/";

$home_page = "home_page.php";

// login expire

$cookie_time = time() + 3600;
$login_cookie = "frackhub";
$session_code = "fh_session";

// Email Settings (Future use for email validation)

$title = "";

$html_body = "";

$sender = "";


?>
