<?php
    include("page_init.php");
    $results = $db->query("fh_users", NULL, NULL, TRUE);
    foreach ($results as $data){
        echo $data["username"] . "<br>";
        echo $data["password"]. "<br>";
        echo $data["email"]. "<br>";
        echo $data["timestamp"]. "<br>";
        $salted = $data["password"] . $data["username"] . $data["email"] . $data["timestamp"];
        $encryption->setPlainText($salted);
        $password = $encryption->classRun();
        $id = $data["id"];
        $values = ["password" => $password];
        $db->update("fh_users", $values, "id=" . $id);
    }